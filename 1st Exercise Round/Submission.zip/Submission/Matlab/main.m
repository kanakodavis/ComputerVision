function main()
%Main Function that starts all the code for the Exercise 1
% Authors
%   * David Pfahler
%   * Matthias Gusenbauer
%   * 
    run_task_colorizing();
    run_task_image_segmentation();
    run_task_blob_detection();
end